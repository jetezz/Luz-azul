#pragma once
#ifndef DECLARACIONTGAMEOBJECTCOL
#define DECLARACIONTGAMEOBJECTCOL


#include <cpctelera.h>

typedef struct {
    u8 num;   
    u8 posx,posy;    
    u8 sprite;       
} TGameObjectCol;

#endif // DECLARACIONTGAMEOBJECTCOL