#include <cpctelera.h>

void crearMapa(u8 id);