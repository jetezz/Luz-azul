/*
;;------------------------------LuzAzul------------------------------------
;;
;;    This program is free software: you can redistribute it and/or modify
;;    it under the terms of the GNU General Public License as published by
;;    the Free Software Foundation, either version 3 of the License, or
;;    any later version.
;;
;;    This program is distributed in the hope that it will be useful,
;;    but WITHOUT ANY WARRANTY; without even the implied warranty of
;;    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;;    GNU General Public License for more details.
;;
;;    You should have received a copy of the GNU General Public License
;;    along with this program.  If not, see <https://www.gnu.org/licenses/>.
;;
;;---------------------------------------------------------------------------------
;;
;;======================================================================================================================================================
;; Title:  LuzAzul                                                               
;; Team: Code Of Light                     -- 
;; Programmer and music designer: 
;; Jesús Cuadra Téllez             --  cuadrabc2015@gmail.com
;; https://www.linkedin.com/in/jesus-cuadra-tellez-0931a6189/
;; Art director and game designer:
;; Ignacio Naranjo Ruiz                     --  i_naranjo_ruiz@hotmail.com      ;; https://www.linkedin.com/in/inaranjoruiz/
;;   
;; Date: 03/11/2020
;;=======================================================================================================================================================
*/
#include "mapa.h"
#include "mapa1.h"
#include "Walls.h"

#define  Punto_Inicial_De_Pantalla   cpctm_screenPtr(CPCT_VMEM_START, 0, 0)

void crearMapa(u8 id){

    cpct_etm_setDrawTilemap4x8_ag(map_W, map_H, map_W, tiles_00);
    cpct_etm_drawTilemap4x8_ag(Punto_Inicial_De_Pantalla, map);

}