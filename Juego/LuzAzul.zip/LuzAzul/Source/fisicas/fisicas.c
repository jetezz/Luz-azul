/*
;;------------------------------LuzAzul------------------------------------
;;
;;    This program is free software: you can redistribute it and/or modify
;;    it under the terms of the GNU General Public License as published by
;;    the Free Software Foundation, either version 3 of the License, or
;;    any later version.
;;
;;    This program is distributed in the hope that it will be useful,
;;    but WITHOUT ANY WARRANTY; without even the implied warranty of
;;    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;;    GNU General Public License for more details.
;;
;;    You should have received a copy of the GNU General Public License
;;    along with this program.  If not, see <https://www.gnu.org/licenses/>.
;;
;;---------------------------------------------------------------------------------
;;
;;======================================================================================================================================================
;; Title:  LuzAzul                                                               
;; Team: Code Of Light                     -- 
;; Programmer and music designer: 
;; Jesús Cuadra Téllez             --  cuadrabc2015@gmail.com
;; https://www.linkedin.com/in/jesus-cuadra-tellez-0931a6189/
;; Art director and game designer:
;; Ignacio Naranjo Ruiz                     --  i_naranjo_ruiz@hotmail.com      ;; https://www.linkedin.com/in/inaranjoruiz/
;;   
;; Date: 03/11/2020
;;=======================================================================================================================================================
*/
#include "fisicas.h"
#include "constantes.h"




#define     Punto_Inicial_De_Pantalla   cpctm_screenPtr(CPCT_VMEM_START, 4, 16)
#define     posxMax                     7
#define     posyMax                     7
#define     posxMaxEspejo               15
#define     posxminEspejo               9

#define     posMin                      1



u8* calcularPosicionEnPantalla(u8 posx, u8 posy, u8 trans){
    if(trans==no){
        return cpctm_screenPtr(CPCT_VMEM_START, posx*4, posy*16);
    }else{
        return cpctm_screenPtr(CPCT_VMEM_START, posx, posy);
    }

   
}
u8 calcularMaximosyMinimos(u8 movimiento,u8 posx, u8 posy,u8 posicion){   
    u8 maximox;
    u8 minimox;
    if(posicion==posicion_Izquieda){        
        maximox=posxMax;
        minimox=posMin;
    }else{             
        maximox=posxMaxEspejo;
        minimox=posxminEspejo;
    }

    if(movimiento!=mover_SinMovimiento){
        if(movimiento==mover_Izquierda){
            if(posx-1<minimox)
            movimiento=mover_SinMovimiento;
        }else if(movimiento==mover_Arriba){
            if(posy-1<posMin)
            movimiento=mover_SinMovimiento;
        }else if(movimiento==mover_Derecha){
            if(posx+1>maximox)
            movimiento=mover_SinMovimiento;
        }else if(movimiento==mover_Abajo){
            if(posy+1>posyMax)
            movimiento=mover_SinMovimiento;
        }
    }
    return movimiento;
}
u8 comprobarColisiones1vs1(u8 posx, u8 posy,u8 posxRock, u8 posyRock){    
    if(posx==posxRock && posy==posyRock){        
        return hay_Colision;
    }else{
        return no_Hay_Colision;
    }
}