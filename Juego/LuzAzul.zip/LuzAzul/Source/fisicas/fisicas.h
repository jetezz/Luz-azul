
#include <cpctelera.h>



void initFisicas();
u8* calcularPosicionEnPantalla(u8 posx, u8 posy, u8 trans);
u8 calcularMaximosyMinimos (u8 movimiento,u8 posx, u8 posy, u8 posicion);
u8 comprobarColisiones1vs1(u8 posx, u8 posy,u8 posxRock, u8 posyRock);
