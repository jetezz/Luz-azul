#include "nivel10_03.h"

void crearnivel10_03(){

//player  portal puertas y marco
createPlayer(3,3);
createMarco(no);
createPortal(no);
createPuerta(3,2,sprite_Puerta_B,nivel_10_05);
createPuerta(2,2,sprite_Puerta_B,nivel_10_04);

//collecionables

//decoracion muros
crearMuro(1,1,4,4,sprite_Muro_Polvo1,posicion_Izquieda);

}
