#include "nivel10_05.h"

void crearnivel10_05(){
    //player  portal puertas y marco
createPlayer(2,3);
createMarco(no);
createPortal(no);
createPuerta(3,3,sprite_Puerta_B,nivel_10);


//collecionables
createColeccionabeFamilia(3,2,sprite_familia3,11);

//decoracion muros
crearMuro(1,1,4,4,sprite_Muro_Polvo1,posicion_Izquieda);

}
