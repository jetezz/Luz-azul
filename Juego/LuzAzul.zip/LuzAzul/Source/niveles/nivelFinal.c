#include "nivelFinal.h"

void crearnivelFinal(){
    //player  portal puertas y marco
createPlayer(4,5);
createMarco(no);
createPortal(no);


//rocas móviles (separando id por espacios)
cambiarMov(mover_1);

cambiarMov(mover_Linea);



cambiarMov(sin_Movimiento);


//collecionables


//decoracion muros

//decoracion simetricos


//decoracion izquierda
createRoca(1,1,sprite_PrinceofPersia1_G,1);
createRoca(2,1,sprite_PrinceofPersia2_G,1);
createRoca(1,2,sprite_amstrad,1);
createRoca(1,3,sprite_PrinceofPersia3,1);
createRoca(2,2,sprite_familia1,1);
createRoca(2,3,sprite_amstradTape,1);
createRoca(5,4,sprite_familia2,1);
createRoca(5,5,sprite_Rock_B,1);
createRoca(6,4,sprite_familia4,1);
createRoca(6,5,sprite_Rock_B,1);
createRoca(6,6,sprite_familia3,1);

}
