#include "nivel10_01.h"

void crearnivel10_01(){
   //player  portal puertas y marco
createPlayer(2,2);
createMarco(no);
createPortal(no);
createPuerta(3,3,sprite_Puerta_B,nivel_10_03);

//collecionables

//decoracion muros
crearMuro(1,1,4,4,sprite_Muro_Polvo1,posicion_Izquieda);
 
}
