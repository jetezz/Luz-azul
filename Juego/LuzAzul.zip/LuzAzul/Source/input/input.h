#include <cpctelera.h>

void scanKey();
u8 keyFire();
u8 keyR();
u8 keyD();
u8 keyP();
u8 keyM();
u8 keyIntro();
u8 keyEscape();
u8 keySpace();



u8 movimientoPlayer();