
/*
;;------------------------------LuzAzul------------------------------------
;;
;;    This program is free software: you can redistribute it and/or modify
;;    it under the terms of the GNU General Public License as published by
;;    the Free Software Foundation, either version 3 of the License, or
;;    any later version.
;;
;;    This program is distributed in the hope that it will be useful,
;;    but WITHOUT ANY WARRANTY; without even the implied warranty of
;;    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;;    GNU General Public License for more details.
;;
;;    You should have received a copy of the GNU General Public License
;;    along with this program.  If not, see <https://www.gnu.org/licenses/>.
;;
;;---------------------------------------------------------------------------------
;;
;;======================================================================================================================================================
;; Title:  LuzAzul                                                               
;; Team: Code Of Light                     -- 
;; Programmer and music designer: 
;; Jesús Cuadra Téllez             --  cuadrabc2015@gmail.com
;; https://www.linkedin.com/in/jesus-cuadra-tellez-0931a6189/
;; Art director and game designer:
;; Ignacio Naranjo Ruiz                     --  i_naranjo_ruiz@hotmail.com      ;; https://www.linkedin.com/in/inaranjoruiz/
;;   
;; Date: 03/11/2020
;;=======================================================================================================================================================
*/
#include "input.h"
#include "constantes.h"

void scanKey(){
    cpct_scanKeyboard_f();
}


u8 keyFire(){
    u8 pulsada=0;
    if(cpct_isKeyPressed (Key_Space))
        pulsada=1;
    return pulsada; 
}
u8 keyR(){
    u8 pulsada=no;
    if(cpct_isKeyPressed (Key_R))
        pulsada=si;
    return pulsada; 
}
u8 keyD(){
    u8 pulsada=no;
    if(cpct_isKeyPressed (Key_D))
        pulsada=si;
    return pulsada; 
}
u8 keyP(){
    u8 pulsada=no;
    if(cpct_isKeyPressed (Key_S))
        pulsada=si;
    return pulsada; 
}
u8 keyM(){
    u8 pulsada=no;
    if(cpct_isKeyPressed (Key_M))
        pulsada=si;
    return pulsada; 
}
u8 keyIntro(){
    u8 pulsada=no;
    if(cpct_isKeyPressed(Key_Return))
        pulsada=si;
    return pulsada; 
}
u8 keyEscape(){
    u8 pulsada=no;
    if(cpct_isKeyPressed(Key_Esc))
        pulsada=si;
    return pulsada;
}
u8 keySpace(){
    u8 pulsada=no;
    if(cpct_isKeyPressed(Key_Space))
        pulsada=si;
    return pulsada;
}







u8 movimientoPlayer(){
    u8 pulsada=0;
    u8 movimiento=mover_SinMovimiento;
    if(cpct_isKeyPressed (Key_CursorUp)){
        movimiento=mover_Arriba;
        pulsada=1;
    }
    if(cpct_isKeyPressed (Key_CursorDown)){
         movimiento=mover_Abajo;
         if(pulsada==1)
         return mover_SinMovimiento;
         pulsada=1;
    }
    if(cpct_isKeyPressed (Key_CursorLeft)){
        movimiento=mover_Izquierda;
         if(pulsada==1)
         return mover_SinMovimiento;
         pulsada=1;
    }
    if(cpct_isKeyPressed (Key_CursorRight)){
        movimiento=mover_Derecha;
         if(pulsada==1)
         return mover_SinMovimiento;         
    }
    return movimiento;
}