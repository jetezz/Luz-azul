#include <cpctelera.h>

extern u8 contadorLuz;
extern u8 contadorFamilia;
extern u8 contadorAmstr;
extern u8 contadorPasos;





void asd();
void initHud();
void actualizarHud(u8 luz, u8 familia,u8 amstr, u8 pasos);


    
